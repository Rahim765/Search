import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class BDS {


    public static void search(State initialState){
        State goalState = new State(initialState.getGraph(), -1, null);

        for (int i = 0; i <goalState.getGraph().size() ; i++) {
            goalState.getGraph().getNode(i).changeColorTo(Color.Green);
        }
        Queue<State> frontier = new LinkedList<State>();
        Hashtable<String, Boolean> inFrontier = new Hashtable<>();
        Hashtable<String, Boolean> explored = new Hashtable<>();

        Queue<State> frontier2 = new LinkedList<State>();
        Hashtable<String, Boolean> inFrontier2 = new Hashtable<>();
        Hashtable<String, Boolean> explored2 = new Hashtable<>();

        if(isGoal(initialState)){
            result(initialState);
            return;
        }
        frontier.add(initialState);
        inFrontier.put(initialState.hash(),true);

        frontier2.add(goalState);
        inFrontier2.put(goalState.hash(),true);


        while (!frontier.isEmpty() && !frontier2.isEmpty()){

            State tempState = frontier.poll();
            inFrontier.remove(tempState.hash());
            explored.put(tempState.hash(),true);
            ArrayList<State> children = tempState.successor();

            State tempState2 = frontier2.poll();
            inFrontier2.remove(tempState2.hash());
            explored2.put(tempState2.hash(),true);
            ArrayList<State> children2 = tempState2.successor();

          for(int i = 0;i<children.size();i++){
                if(!(inFrontier.containsKey(children.get(i).hash()))
                        && !(explored.containsKey(children.get(i).hash()))) {
                    for (int j = 0; j <children2.size() ; j++) {
                            if (children.get(i).hash().equals(children2.get(j).hash())) {
                                result(children.get(i));
                                result2(children2.get(j));
                                return;
                           }
                        frontier2.add(children2.get(j));
                        inFrontier2.put(children2.get(j).hash(), true);
                    }

                    frontier.add(children.get(i));
                    inFrontier.put(children.get(i).hash(), true);


                }
            }
        }
    }

    private static boolean isGoal(State state){
        for (int i = 0; i < state.getGraph().size(); i++) {
            if(state.getGraph().getNode(i).getColor() == Color.Red
                    || state.getGraph().getNode(i).getColor() == Color.Black){
                return false;
            }
        }
        return true;
    }

    private static void result(State state){
        Stack<State> states = new Stack<State>();
        while (true){
            states.push(state);
            if(state.getParentState() == null){
                break;
            }
            else {
                state = state.getParentState();
            }
        }
        try {
            FileWriter myWriter = new FileWriter("BdsResult.txt");
            System.out.println("initial state : ");
            while (!states.empty()){
                State tempState = states.pop();
                if(tempState.getSelectedNodeId() != -1) {
                    System.out.println("selected id : " + tempState.getSelectedNodeId());
                }
                tempState.getGraph().print();

                myWriter.write(tempState.getSelectedNodeId()+" ,");
                myWriter.write(tempState.outputGenerator()+"\n");
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    private static void result2 (State state){
        Stack<State> states1 = new Stack<State>();
        while (true){
            states1.push(state);
            if(state.getParentState() == null){
                break;
            }
            else {
                state = state.getParentState();
            }
        }
        Stack<State> states  = new Stack<>();
        while (true){
            if (states1.size() == 1){
                break;
            }
            else{
                states.push(states1.pop());
            }
        }
        try {
            FileWriter myWriter = new FileWriter("BdsResult.txt", true);
            while (!states.empty()){
                State tempState = states.pop();
                if(tempState.getSelectedNodeId() != -1) {
                    System.out.println("selected id : " + tempState.getSelectedNodeId());
                }
                tempState.getGraph().print();

                myWriter.write(tempState.getSelectedNodeId()+" ,");
                myWriter.write(tempState.outputGenerator()+"\n");
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

}
