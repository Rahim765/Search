public enum Color {
    Green, Red, Black;
}
