import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Stack;

public class GBFS {



    public static void search(State initialState){
        ArrayList<State> frontier = new ArrayList<>();
        Hashtable<String, Boolean> inFrontier = new Hashtable<>();
        Hashtable<String, Boolean> explored = new Hashtable<>();
        if(isGoal(initialState)){
            result(initialState);
            return;
        }
        frontier.add(initialState);
        inFrontier.put(initialState.hash(),true);
        while (!frontier.isEmpty()){
            State tempState = frontier.get(0);
            frontier.remove(0);
            inFrontier.remove(tempState.hash());
            explored.put(tempState.hash(),true);
            ArrayList<State> children = tempState.successor();
            for(int i = 0;i<children.size();i++){
                if(!(inFrontier.containsKey(children.get(i).hash()))
                        && !(explored.containsKey(children.get(i).hash()))) {
                    if (isGoal(children.get(i))) {
                        result(children.get(i));
                        return;
                    }
                    frontier.add(children.get(i));
                    inFrontier.put(children.get(i).hash(), true);
                }
            }
            int min =Integer.MAX_VALUE ;
            int index= 0 ;
            for (int i = 0; i <frontier.size() ; i++) {
                int f = h(frontier.get(i)) ;
                if (f <= min){
                    min = f;
                    index = i;
                }
            }
            State temp = frontier.get(0);
            frontier.set(0 , frontier.get(index)) ;
            frontier.set(index , temp);
        }
    }

    public static int h(State state) {
        ArrayList<Node> arrayList = new ArrayList<>();
        int count = 0;
        Node  temp = null;
        for (int i = 0; i < state.getGraph().size(); i++) {
            if (state.getGraph().getNode(i).getColor() == Color.Black
                    || state.getGraph().getNode(i).getColor() == Color.Red) {
                arrayList.add(state.getGraph().getNode(i));
            }
        }
        while (!arrayList.isEmpty()) {
            int max = 0;
            for (int k = 0; k < arrayList.size(); k++) {

                LinkedList<Integer> neighbor = arrayList.get(k).getNeighborsIds();

                int red_black_neghbors = 0;
                for (int i = 0; i < neighbor.size(); i++) {
                    for (int j = 0; j < arrayList.size(); j++) {
                        if (neighbor.get(i) == arrayList.get(j).getId()) {
                            red_black_neghbors++;
                        }
                    }
                }

                if (red_black_neghbors >= max) {
                    max = red_black_neghbors;
                    temp =arrayList.get(k);
                }

            }

            LinkedList<Integer> remove = temp.getNeighborsIds();
            arrayList.remove(temp);
            for (int i = 0; i <remove.size() ; i++) {
                for (int j = 0; j <arrayList.size() ; j++) {
                    if (arrayList.get(j).getId() == remove.get(i)){
                        arrayList.remove(j);
                        break;
                    }
                }

            }

            count++;

        }
        return count;
    }

    private static boolean isGoal(State state){
        for (int i = 0; i < state.getGraph().size(); i++) {
            if(state.getGraph().getNode(i).getColor() == Color.Red
                    || state.getGraph().getNode(i).getColor() == Color.Black){
                return false;
            }
        }
        return true;
    }

    private static void result(State state){
        Stack<State> states = new Stack<State>();
        while (true){
            states.push(state);
            if(state.getParentState() == null){
                break;
            }
            else {
                state = state.getParentState();
            }
        }
        try {
            FileWriter myWriter = new FileWriter("GbfsResult.txt");
            System.out.println("initial state : ");
            while (!states.empty()){
                State tempState = states.pop();
                System.out.println("h(N) = " + h(tempState));
                if(tempState.getSelectedNodeId() != -1) {
                    System.out.println("selected id : " + tempState.getSelectedNodeId());
                }
                tempState.getGraph().print();

                myWriter.write(tempState.getSelectedNodeId()+" ,");
                myWriter.write(tempState.outputGenerator()+"\n");
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }




}
